New function in `luaSystem.cpp` called `lua_getcardid`, used as `System.getCardID()`, which gets the title ID of the current game card.

Based on commit [`230af27`](https://github.com/Rinnegatamante/lpp-3ds/tree/230af270e010785d767716317357d57a201d5773).