Result amExit_norm(){
	amExit();
	return 0;
}

Result csndExit_norm(){
	csndExit();
	return 0;
}

Result ndspExit_norm(){
	ndspExit();
	return 0;
}