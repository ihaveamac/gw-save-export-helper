// Common.hpp
// @author: Nanni

#ifndef COMMON_HPP_INC
#define COMMON_HPP_INC

#include <string>
#include <vector>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <sstream>

#define PLATFORM_3DS

#endif // COMMON_HPP_INC
